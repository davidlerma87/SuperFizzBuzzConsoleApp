﻿using System;

namespace SuperFizzBuzz
{
    public interface ISuperFizzBuzz
    {
        string[] RunClassic();
        string[] RunAdvance();
    }
}
